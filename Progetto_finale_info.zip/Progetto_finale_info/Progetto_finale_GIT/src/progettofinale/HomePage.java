package progettofinale;
import model.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.*;
/**
 *
 * @author Catellani, Gambetti, Maschio, Moretti
 */
public class HomePage extends javax.swing.JFrame implements ActionListener{
    public JPanel cardPanel;
    public static ArrayList<Prodotto> prodotti;
    final int IMMAGINI = 32;
    public static float[] prezziFissi = {39.0f, 39.0f, 39.0f, 39.0f, 39.0f, 69.0f,
                                         69.0f, 69.0f, 69.0f, 69.0f, 12.0f, 24.0f
                                        };
    public static String nomiProdotti[] = {"Accappatoio Versace", "Maglione Polo Ralph Lauren", "Jordan 4 Travis", "Cappello Casa Blanca","Felpa Off-White", "T-shirt Dsquared2", "Canotta LeSusnshine","Profumo Louis Vuitton", "Occhiali da sole Fendi", "Jeans Evisu",
                                           "Borsa Louis Vuitton", "Cintura Gucci", "Tacchi Saint Laurent", "Calze Nike", "Vestito Prada", "Zaino nero", "Jeans donna", "Good Girl", "Costume Diesel", "Collana Bulgari",
                                           "T-shirt Viandante", "T-shirt Italia e Germania", "T-shirt libertà","T-shirt Creazione", "T-shirt Napoleone", "Felpa Foscolo", "Felpa Il bacio", "Felpa Big Lisa", "Felpa Dama con ermellino", "Felpa Homer", 
                                           "Calze DropZone", "Cappello DropZone"
                                          };
    
    public HomePage() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setLayout(new BorderLayout());
        
        this.numCarrello.setOpaque(true);
        this.numCarrello.setFont(new Font("Arial", Font.BOLD,12));

        
        CardLayout cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        prodotti = popola(IMMAGINI);
        
        aggiornaContCarrelloDaFile();

        //Sezione uomo
        JPanel uomoPanel = new JPanel();
        uomoPanel.setBackground(new Color(255,255,255));
        uomoPanel.add(new JLabel("Benvenuto nella sezione UOMO"));
        generaPagine(prodotti, uomoPanel,0,10);

        //Sezione donna
        JPanel donnaPanel = new JPanel();
        donnaPanel.setBackground(new Color(255,255,255));
        donnaPanel.add(new JLabel("Benvenuta nella sezione DONNA"));
        generaPagine(prodotti, donnaPanel,10, 20);
        
        // Sezione principale
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(255,255,255));
        mainPanel.setLayout(null);
        mainPanel.add(new JLabel("Benvenuto/a nella sezione PRINCIPALE"));
        generaPrincipale(prodotti, mainPanel, 20, IMMAGINI);

        
        cardPanel.add(uomoPanel, "UOMO");
        cardPanel.add(donnaPanel, "DONNA");

        
        getContentPane().add(jPanel1, BorderLayout.NORTH);
        getContentPane().add(cardPanel, BorderLayout.CENTER);

    }
    
    public static ArrayList<Prodotto> popola(int numeroImmagini) {
        ArrayList<Prodotto> prodotti = new ArrayList<>();
        
        for (int i = 0; i <numeroImmagini; i++) {
            float prezzo;
            if (i >= 20 && i <= 31) {
                prezzo = prezziFissi[i - 20];
            } else {
                prezzo = (float)(Math.random() *950 + 50);
            }
        prezzo = (float) (Math.round(prezzo) + 0.99f);

            switch (i) {
                case 2:
                case 12:
                case 13:
                case 30: {
                    Calzature p = new Calzature(prezzo, "src\\immagini_prodotti\\" + i + ".png", Prodotto.taglie[0], nomiProdotti[i]);
                    prodotti.add(p);
                    break;
                }

                case 7:
                case 17: {
                    Profumo p = new Profumo(prezzo, "src\\immagini_prodotti\\" + i + ".png", Prodotto.taglie[0], nomiProdotti[i]);
                    prodotti.add(p);
                    break;
                }

                case 8:
                case 10:   
                case 11:
                case 15:
                case 19:{
                    Prodotto p = new Prodotto(prezzo, "src\\immagini_prodotti\\" + i + ".png", Prodotto.taglie[0], nomiProdotti[i]);
                    prodotti.add(p);
                    break;
                }

                default: {
                    Abbigliamento p = new Abbigliamento(prezzo, "src\\immagini_prodotti\\" + i + ".png", Prodotto.taglie[0], nomiProdotti[i]);
                    prodotti.add(p);
                    break;
                }
            }
            
            
            
        }
        return prodotti;
    }
    
    public void aggiornaContCarrelloDaFile() {
        File file = new File("carrello.csv");
        Carrello.contCarrello = 0;
        Carrello.totaleCarrello = 0;

        if(!file.exists()){
            JOptionPane.showMessageDialog(this, "Il file"+file.getName()+"non esiste!", "Attenzione", JOptionPane.WARNING_MESSAGE);
        }

        else{
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String riga;
                boolean primaRiga = true;
                while ((riga = br.readLine()) != null) {
                    if (primaRiga) {
                        primaRiga = false; 
                        continue;
                    }
                    if (!riga.trim().isEmpty()) {
                        Carrello.contCarrello++;
                        Carrello.totaleCarrello += Float.parseFloat(riga.split(",")[2].replace("€", ""));
                        Carrello.totaleCarrello = (float)Math.round(Carrello.totaleCarrello*100)/100;
                        
                    }
                }
            } catch (IOException e) {
                System.out.println("Errore nella lettura del file"+file.getName());
            }
            
            aggiornaNumCarrello();
        }
    }
    
    public static void aggiungiProdotto(Prodotto p) throws IOException{
        Carrello.bw = new BufferedWriter(new FileWriter("carrello.csv", true));
        String riga = "";
        if(p instanceof Profumo){
            riga = p.getNome()+","+p.getTaglia()+","+ ((Profumo) p).regolaPrezzo()+"€,"+"\n";
        }
        else{
            riga = p.getNome()+","+p.getTaglia()+","+ p.getPrezzo()+"€,"+"\n";
        }
        Carrello.bw.write(riga);
        Carrello.bw.flush();
        Carrello.bw.close();
        JOptionPane.showMessageDialog(null, "Articolo: '"+p.getNome()+"' aggiunto al carrello","Carrello" , JOptionPane.PLAIN_MESSAGE);
        
        Carrello.contCarrello++;
        
        aggiornaNumCarrello();
    
    }
    
    public static void controlloTaglia(Prodotto p){
        String[] taglieDisponibili = Prodotto.taglie;

        if (p instanceof Abbigliamento) 
            taglieDisponibili = Abbigliamento.taglie;
         else if (p instanceof Calzature) 
            taglieDisponibili = Calzature.taglie;
         else if (p instanceof Profumo) 
            taglieDisponibili = Profumo.taglie;
            
        String tagliaSelezionata = (String) JOptionPane.showInputDialog(null,"Seleziona una taglia:","Selezione taglia",JOptionPane.QUESTION_MESSAGE,null,taglieDisponibili,taglieDisponibili[0]);    
         if (tagliaSelezionata != null && !tagliaSelezionata.equals(taglieDisponibili[0])) {
                p.setTaglia(tagliaSelezionata);
            try {
                aggiungiProdotto(p);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Errore nell'aggiunta del prodotto al carello", "ERRORE", JOptionPane.ERROR_MESSAGE);
            }
         }
         else{
             JOptionPane.showMessageDialog(null, "Taglia inserita non valida", "ERRORE", JOptionPane.ERROR_MESSAGE);
         }
    }
    
    public static void aggiornaNumCarrello(){
        HomePage.numCarrello.setText(""+Carrello.contCarrello);
    }
    
    public void generaPagine(ArrayList<Prodotto> prodotti, JPanel sezione, int start, int stop){
        int x = 195, y = 10;
        final int DIM_IMG = 100;  
        final int H = 30;  
        final int COLONNE = 6;
        sezione.setLayout(null);
        
        for(int i=start; i<stop;i++){
            JLabel immagine = new JLabel(new ImageIcon(prodotti.get(i).getPercorsoIMG()));
            String pr = String.format("%.2f",prodotti.get(i).getPrezzo());
            JLabel prezzo = new JLabel(pr+"€");
            prezzo.setFont(new Font("Arial", Font.BOLD,14));
            JButton bottone = new JButton("ACQUISTA");
            bottone.setActionCommand(""+i); 
            
            prezzo.setBounds(x+25, y + DIM_IMG + 5, DIM_IMG, H);
            immagine.setBounds(x, y, DIM_IMG, DIM_IMG);
            bottone.setBounds(x, y + DIM_IMG + H + 10, DIM_IMG, H);
            
            bottone.setBackground(new Color(0,102,204));
            bottone.setFont(new Font("Arial", Font.BOLD,12));
            bottone.setForeground(new Color(255,255,255));
            
            
            sezione.add(prezzo);
            sezione.add(bottone);
            sezione.add(immagine);
            
            x += DIM_IMG + 10; 

            
            if (x / (DIM_IMG + 10) % COLONNE == 0) {
                x = 195; 
                y += 2 * (H + 10 + DIM_IMG); 
            }
            
            //ActionListener
            bottone.addActionListener(this); 
        }
        
    }
    
    public static void generaScrittaScorrevole(JPanel sezione){
        JLabel scrittaScrorrevole = new JLabel("Benvenuto su DropZone - Le migliori offerte ti aspettano! Effettua una spesa minima di 2000€ per girare la ruota dei premi!");
        scrittaScrorrevole.setFont(new Font("Arial", Font.BOLD, 18));
        scrittaScrorrevole.setForeground(new Color(0,102,204));

        JPanel panelScorrevole = new JPanel(null); 
        panelScorrevole.setBounds(0, 0, 900, 30); 
        panelScorrevole.setBackground(Color.WHITE);
        scrittaScrorrevole.setBounds(panelScorrevole.getWidth(), 5, 1150, 20); 
        panelScorrevole.add(scrittaScrorrevole);
        sezione.add(panelScorrevole);
        
        Timer timer = new Timer(20, new ActionListener() {
            int x = panelScorrevole.getWidth(); // posizione iniziale

            @Override
            public void actionPerformed(ActionEvent e) {
                x -= 2; 
                if (x + scrittaScrorrevole.getWidth() < 0) {
                    x = panelScorrevole.getWidth();
                }
                scrittaScrorrevole.setLocation(x, scrittaScrorrevole.getY());
            }
        });
        timer.start();
    }
    
    public void generaPrincipale(ArrayList<Prodotto> prodotti, JPanel sezione, int start, int stop) {
        int x = 45, y = 40;  
        final int DIM_IMG = 200;  
        final int H = 30;  
        final int COLONNE = 4;  
        final int SPAZIO = 10;  

        sezione.setLayout(null); 
        
        generaScrittaScorrevole(sezione);

        for (int i = start; i < stop; i++) {
            JLabel immagine = new JLabel(new ImageIcon(prodotti.get(i).getPercorsoIMG()));
            immagine.setBounds(x, y, DIM_IMG, DIM_IMG);  

            String pr = String.format("%.2f", prodotti.get(i).getPrezzo());
            JLabel prezzo = new JLabel(pr + "€");
            prezzo.setFont(new Font("Arial", Font.BOLD,18));
            int prezzoX = x + (DIM_IMG - prezzo.getPreferredSize().width) / 2;  
            prezzo.setBounds(prezzoX, y + DIM_IMG, DIM_IMG, H);  

            JButton bottone = new JButton("ACQUISTA");
            bottone.setActionCommand("" + i);
            bottone.setBounds(x, y + DIM_IMG + H + 10, DIM_IMG, H);

            bottone.setBackground(new Color(0, 102, 204));
            bottone.setFont(new Font("Arial", Font.BOLD, 12));
            bottone.setForeground(new Color(255, 255, 255));

            sezione.add(immagine);
            sezione.add(prezzo);
            sezione.add(bottone);

            x += DIM_IMG + SPAZIO;
            if ((i + 1) % COLONNE == 0 && (i + 1) < stop) {
            x = 45;
            y += DIM_IMG + H + 10 + 30;
            }
            
            bottone.addActionListener(this);
        }


        sezione.setPreferredSize(new Dimension(sezione.getPreferredSize().width, y + DIM_IMG + H + 10 + 30));

        JScrollPane scrollPane = new JScrollPane(sezione);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        cardPanel.add(scrollPane, "PRINCIPALE");
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        donna = new javax.swing.JButton();
        uomo = new javax.swing.JButton();
        logo = new javax.swing.JButton();
        numCarrello = new javax.swing.JLabel();
        carrello = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(965, 625));

        jPanel1.setBackground(new java.awt.Color(0, 102, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        donna.setBackground(new java.awt.Color(0, 102, 204));
        donna.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        donna.setForeground(new java.awt.Color(255, 255, 255));
        donna.setText("DONNA");
        donna.setBorder(null);
        donna.setBorderPainted(false);
        donna.setContentAreaFilled(false);
        donna.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                donnaActionPerformed(evt);
            }
        });
        jPanel1.add(donna, new org.netbeans.lib.awtextra.AbsoluteConstraints(129, 0, 123, 93));

        uomo.setBackground(new java.awt.Color(0, 102, 204));
        uomo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        uomo.setForeground(new java.awt.Color(255, 255, 255));
        uomo.setText("UOMO");
        uomo.setBorder(null);
        uomo.setBorderPainted(false);
        uomo.setContentAreaFilled(false);
        uomo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uomoActionPerformed(evt);
            }
        });
        jPanel1.add(uomo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 123, 93));

        logo.setForeground(new java.awt.Color(0, 102, 204));
        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/progettofinale/dropZone.jpg"))); // NOI18N
        logo.setBorderPainted(false);
        logo.setContentAreaFilled(false);
        logo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoActionPerformed(evt);
            }
        });
        jPanel1.add(logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(322, 6, -1, -1));

        numCarrello.setBackground(new java.awt.Color(255, 0, 0));
        numCarrello.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        numCarrello.setForeground(new java.awt.Color(255, 255, 255));
        numCarrello.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        numCarrello.setText("0");
        numCarrello.setOpaque(true);
        numCarrello.setVerifyInputWhenFocusTarget(false);
        jPanel1.add(numCarrello, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 30, 20, 20));

        carrello.setBackground(new java.awt.Color(0, 102, 204));
        carrello.setIcon(new javax.swing.ImageIcon(getClass().getResource("/progettofinale/img_carrello_bianca.png"))); // NOI18N
        carrello.setBorder(null);
        carrello.setBorderPainted(false);
        carrello.setContentAreaFilled(false);
        carrello.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                carrelloMouseClicked(evt);
            }
        });
        carrello.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carrelloActionPerformed(evt);
            }
        });
        jPanel1.add(carrello, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 0, 85, 93));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(397, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void carrelloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_carrelloActionPerformed
    }//GEN-LAST:event_carrelloActionPerformed

    private void donnaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_donnaActionPerformed
        ((CardLayout) cardPanel.getLayout()).show(cardPanel, "DONNA");
    }//GEN-LAST:event_donnaActionPerformed

    private void uomoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uomoActionPerformed
        ((CardLayout) cardPanel.getLayout()).show(cardPanel, "UOMO");
    }//GEN-LAST:event_uomoActionPerformed

    private void carrelloMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_carrelloMouseClicked
        try {
            new Carrello().setVisible(true);
        } catch (IOException ex) {
            System.out.println("ERRORE!");
        }
    }//GEN-LAST:event_carrelloMouseClicked

    private void logoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoActionPerformed
        ((CardLayout) cardPanel.getLayout()).show(cardPanel, "PRINCIPALE");
    }//GEN-LAST:event_logoActionPerformed

    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomePage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton carrello;
    private javax.swing.JButton donna;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton logo;
    public static javax.swing.JLabel numCarrello;
    private javax.swing.JButton uomo;
    // End of variables declaration//GEN-END:variables

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton bottone = (JButton) e.getSource();
        int indice = Integer.parseInt(bottone.getActionCommand());
        Prodotto prodotto = prodotti.get(indice);
        
        controlloTaglia(prodotto);
        
}

}
