package progettofinale;
import java.awt.*;
import java.awt.event.*;
import javax.swing.text.*;
import java.io.*;
import java.io.IOException;
import javax.swing.*;
/**
 *
 * @author Maschio, Catellani, Gambetti, Moretti
 */
public class Pagamento extends javax.swing.JFrame {
    Timer t1;
    public Pagamento() {
        initComponents();
        formattaNumeroCarta(cartaTXT);
        formattaCVV(cvvTXT);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        this.getContentPane().setBackground(new Color(0,104,202));
        caricamentoLabel.setVisible(false);
        
                
        listaMese.removeAllItems();
        for (int i = 1; i <= 12; i++) {
            listaMese.addItem(String.format("%02d", i));
        }

        listaAnno.removeAllItems();
        for (int i = 2026; i <= 2035; i++) {
            listaAnno.addItem(""+i);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titoloLabel = new javax.swing.JLabel();
        titolareLabel = new javax.swing.JLabel();
        bottonePagamento = new javax.swing.JButton();
        cartaLabel = new javax.swing.JLabel();
        cvvLabel = new javax.swing.JLabel();
        scadenzaLabel = new javax.swing.JLabel();
        titolareTXT = new javax.swing.JTextField();
        cvvTXT = new javax.swing.JTextField();
        cartaTXT = new javax.swing.JTextField();
        listaAnno = new javax.swing.JComboBox<>();
        listaMese = new javax.swing.JComboBox<>();
        caricamentoLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(330, 325));

        titoloLabel.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        titoloLabel.setForeground(new java.awt.Color(255, 255, 255));
        titoloLabel.setText("Completa il pagamento");

        titolareLabel.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        titolareLabel.setForeground(new java.awt.Color(255, 255, 255));
        titolareLabel.setText("Titolare carta:");

        bottonePagamento.setForeground(new java.awt.Color(0, 0, 0));
        bottonePagamento.setText("Effettua pagamento");
        bottonePagamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottonePagamentoActionPerformed(evt);
            }
        });

        cartaLabel.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        cartaLabel.setForeground(new java.awt.Color(255, 255, 255));
        cartaLabel.setText("Num. carta:");

        cvvLabel.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        cvvLabel.setForeground(new java.awt.Color(255, 255, 255));
        cvvLabel.setText("CVV:");

        scadenzaLabel.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        scadenzaLabel.setForeground(new java.awt.Color(255, 255, 255));
        scadenzaLabel.setText("Data di scadenza:");

        listaAnno.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        listaMese.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        caricamentoLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/progettofinale/caricamento.gif"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(titoloLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(titolareLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(17, 17, 17)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cartaTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cvvTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(70, 70, 70)
                                .addComponent(listaAnno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(listaMese, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(cartaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(caricamentoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(cvvLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(scadenzaLabel)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(140, 140, 140)
                        .addComponent(titolareTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(bottonePagamento, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(41, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(titoloLabel)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(titolareLabel)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(cartaTXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cvvTXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(listaAnno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(listaMese, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(cartaLabel))
                    .addComponent(caricamentoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(cvvLabel))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addComponent(scadenzaLabel))
                    .addComponent(titolareTXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(190, 190, 190)
                        .addComponent(bottonePagamento))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void rendiVisibile(boolean flag, String str, Color testo, Color sfondo){
        titoloLabel.setText(str);
        titoloLabel.setForeground(testo);
        this.getContentPane().setBackground(sfondo);
        titolareLabel.setVisible(flag);
        cartaLabel.setVisible(flag);
        cvvLabel.setVisible(flag);
        scadenzaLabel.setVisible(flag);
        titolareTXT.setVisible(flag);
        cartaTXT.setVisible(flag);
        cvvTXT.setVisible(flag);
        listaMese.setVisible(flag);
        listaAnno.setVisible(flag);
        bottonePagamento.setVisible(flag);
        caricamentoLabel.setVisible(!flag);
    }
    
    private void svuotaCarrello() throws IOException {
        
    if (!Carrello.file.exists()) {
        JOptionPane.showMessageDialog(this, "Il file " + Carrello.file.getName() + " non esiste!", "Attenzione", JOptionPane.WARNING_MESSAGE);
    } else {
        Carrello.contCarrello = 0;
        Carrello.totaleCarrello = 0;
        
        Carrello.br = new BufferedReader(new FileReader(Carrello.file));
        String primaRiga = Carrello.br.readLine();
        Carrello.br.close();

        
        Carrello.bw = new BufferedWriter(new FileWriter(Carrello.file));
        if (primaRiga != null) {
            Carrello.bw.write(primaRiga);
            Carrello.bw.newLine();
        }
        Carrello.bw.flush();
        Carrello.bw.close();

        Carrello.aggiorna();
        HomePage.aggiornaNumCarrello();
        Carrello.totale.setText(Carrello.totaleCarrello+"€");
    }
}

    private void caricamento(String titolare, String numCarta, String cvv, String mese, String anno) {
        rendiVisibile(false,"Attendere prego...",new Color(0,102,204),new Color(255,255,255));

        t1 = new Timer(2000, new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                
                if (titolare.isEmpty() || numCarta.length() != 16 || !numCarta.matches("\\d+") || cvv.length() != 3 || !cvv.matches("\\d+")){
                    JOptionPane.showMessageDialog(Pagamento.this,"Controlla che tutti i dati siano inseriti correttamente.","ERRORE", JOptionPane.ERROR_MESSAGE);
                    rendiVisibile(true,"Completa il pagamento",new Color(255,255,255),new Color(0,102,204));
                } else {
                    JOptionPane.showMessageDialog(Pagamento.this,"Pagamento effettuato con successo!\nGrazie per l'acquisto!","Pagamento", JOptionPane.INFORMATION_MESSAGE);
                    if(Carrello.ricevuta.isSelected()){
                        stampaScontrino();
                    }
                    try {
                        svuotaCarrello();
                    } catch (IOException ex) {
                        System.out.println("Errore in svuotaCarrello()");
                    }
                    dispose();
                }
            }
        });
        t1.setRepeats(false); 
        t1.start(); 
    }
   
    private void stampaScontrino() {
    File scontrino = new File("scontrino.txt");
    try (BufferedWriter bw = new BufferedWriter(new FileWriter(scontrino))) {
        // Header
        bw.write("************ DROPZONE ************");
        bw.newLine();
        bw.write("Data: " + java.time.LocalDateTime.now().toString());
        bw.newLine();
        bw.write("***********************************");
        bw.newLine();

        // Dati pagamento
        String titolare = titolareTXT.getText().trim();
        String numCartaFormatted = cartaTXT.getText().trim();
        String numCartaRaw       = numCartaFormatted.replaceAll("\\s+", "");
        String numCartaMascherato = "**** **** **** " + numCartaRaw.substring(numCartaRaw.length() - 4);
        String mese = (String) listaMese.getSelectedItem();
        String anno = (String) listaAnno.getSelectedItem();


        bw.write("Pagamento con carta:");
        bw.newLine();
        bw.write("Titolare: " + titolare);
        bw.newLine();
        bw.write("Carta: " + numCartaMascherato);
        bw.newLine();
        bw.write("Scadenza: " + mese + "/" + anno);
        bw.newLine();
        bw.write("***********************************");
        bw.newLine();

        // Lettura prodotti dal file carrello
        if (Carrello.file.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(Carrello.file))) {
                String linea;
                boolean primaRiga = true;
                while ((linea = br.readLine()) != null) {
                    if (primaRiga) {
                        primaRiga = false; // Salta intestazione
                        continue;
                    }
                    bw.write(linea);
                    bw.newLine();
                }
            }
        }

        bw.write("***********************************");
        bw.newLine();
        bw.write("Totale pagato: " + Carrello.totaleCarrello + "€");
        bw.newLine();
        bw.write("Grazie per l'acquisto!");
        bw.newLine();
        bw.flush();

        JOptionPane.showMessageDialog(this, "Scontrino generato con successo!", "Scontrino", JOptionPane.INFORMATION_MESSAGE);

    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Errore durante la creazione dello scontrino.", "Errore", JOptionPane.ERROR_MESSAGE);
    }
}
    
    private void formattaNumeroCarta(JTextField textField) {
        ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                if (string != null) {
                    replace(fb, offset, 0, string, attr);
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
                StringBuilder sb = new StringBuilder(currentText);
                sb.replace(offset, offset + length, text);

                String cleaned = sb.toString().replaceAll("\\D", ""); // solo cifre
                if (cleaned.length() > 16) cleaned = cleaned.substring(0, 16);

                StringBuilder formatted = new StringBuilder();
                for (int i = 0; i < cleaned.length(); i++) {
                    if (i > 0 && i % 4 == 0) {
                        formatted.append(" ");
                    }
                    formatted.append(cleaned.charAt(i));
                }

                fb.replace(0, fb.getDocument().getLength(), formatted.toString(), attrs);
            }

            @Override
            public void remove(FilterBypass fb, int offset, int length) throws BadLocationException {
                replace(fb, offset, length, "", null);
            }
        });
    }

    private void formattaCVV(JTextField textField) {
    ((AbstractDocument) textField.getDocument()).setDocumentFilter(new DocumentFilter() {
        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (string != null) {
                replace(fb, offset, 0, string, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            String currentText = fb.getDocument().getText(0, fb.getDocument().getLength());
            StringBuilder sb = new StringBuilder(currentText);
            sb.replace(offset, offset + length, text);

            String cleaned = sb.toString().replaceAll("\\D", "");
            if (cleaned.length() > 3) {
                cleaned = cleaned.substring(0, 3); 
            }

            fb.replace(0, fb.getDocument().getLength(), cleaned, attrs);
        }

        @Override
        public void remove(FilterBypass fb, int offset, int length) throws BadLocationException {
            replace(fb, offset, length, "", null);
        }
    });
}

    private void bottonePagamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottonePagamentoActionPerformed
        String titolare = titolareTXT.getText().trim();
        String cvv = cvvTXT.getText().trim();
        String mese = (String) listaMese.getSelectedItem();
        String anno = (String) listaAnno.getSelectedItem();
        String numCarta = cartaTXT.getText().replaceAll("\\s+", "");
        caricamento(titolare, numCarta, cvv, mese, anno);
    }//GEN-LAST:event_bottonePagamentoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Pagamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Pagamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Pagamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Pagamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Pagamento().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bottonePagamento;
    private javax.swing.JLabel caricamentoLabel;
    private javax.swing.JLabel cartaLabel;
    private javax.swing.JTextField cartaTXT;
    private javax.swing.JLabel cvvLabel;
    private javax.swing.JTextField cvvTXT;
    private javax.swing.JComboBox<String> listaAnno;
    private javax.swing.JComboBox<String> listaMese;
    private javax.swing.JLabel scadenzaLabel;
    private javax.swing.JLabel titolareLabel;
    private javax.swing.JTextField titolareTXT;
    private javax.swing.JLabel titoloLabel;
    // End of variables declaration//GEN-END:variables
}
