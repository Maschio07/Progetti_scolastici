package progettofinale;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class RuotaDellaFortuna extends JPanel implements ActionListener {
    private final static  int numeroSettori = 10;
    private final String[] premiSettori = {
        "Felpa ", "Sconto 10%", "T-shirt", "Sconto 20€",
        "Sconto 20%", "Calze", "Sconto 30€ ",
        "Sconto 5%", "Sconto 5€", "Cappello"
    };
    public static String[] codiciSettori = generaCodici();
    private final int[] angoliSettori = new int[numeroSettori];
    private final Color[] colori = {
        new Color(0, 0, 255, 160),
        new Color(0, 0, 200, 140),
        new Color(0, 100, 255, 180),
        new Color(255, 255, 255, 200)
    };
    private double angolo = 0;
    private Timer timer;
    private double velocita;
    private boolean gira = false;
    private boolean girata = false;

    private final JButton bottoneCentrale;

    public RuotaDellaFortuna() {
        this.setLayout(null);

        bottoneCentrale = new JButton("Spin") {
            @Override
            protected void paintComponent(Graphics g) {
                if (!isOpaque()) {
                    g.setColor(Color.BLACK);
                    g.fillOval(0, 0, getWidth(), getHeight());
                    g.setColor(Color.WHITE);
                    g.setFont(new Font("Arial", Font.BOLD, 18));
                    FontMetrics fm = g.getFontMetrics();
                    int textWidth = fm.stringWidth(getText());
                    int textHeight = fm.getHeight();
                    g.drawString(getText(), (getWidth() - textWidth) / 2, (getHeight() + textHeight / 4) / 2);
                } else {
                    super.paintComponent(g);
                }
            }
        };

        bottoneCentrale.setOpaque(false);
        bottoneCentrale.setContentAreaFilled(false);
        bottoneCentrale.setBorderPainted(false);
        bottoneCentrale.addActionListener(e -> iniziaGiro());

        // Dimensione e posizione del pulsante centrale
        bottoneCentrale.setBounds(225, 225, 100, 100); 
        this.add(bottoneCentrale);

        timer = new Timer(20, this);
        calcolaAngoliSettori();
    }
    
    private static String[] generaCodici() {
        String[] str = new String[numeroSettori];

        for (int i = 0; i < numeroSettori; i++) {
            String codice = "";
            for (int j = 0; j < 5; j++) {
                if (j % 2 == 0) {
                    int cifra = (int)(Math.random() * 10);
                    codice += cifra;
                } else {
                    int ascii = (int)(Math.random() * 26) + 65;
                    codice += (char)ascii;
                }
            }
            str[i] = codice;
    }

    return str;
}
    
    private void calcolaAngoliSettori() {
        int angoloNormale = 360 / numeroSettori;
        for (int i = 0; i < numeroSettori; i++) {
            angoliSettori[i] = angoloNormale;
        }
    }

    private void iniziaGiro() {
        if (!gira) {
            velocita = 0.5 + new Random().nextDouble() * 5;
            gira = true;
            timer.start();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (velocita > 0.01) {
            angolo += velocita;
            velocita *= 0.98;
            repaint();
        } else {
            gira = false;
            timer.stop();

            int angoloGradi = (int) ((360 - Math.toDegrees(angolo % (2 * Math.PI))) % 360);
            int angoloTotale = 0;
            int settoreVinto = 0;

            for (int i = 0; i < numeroSettori; i++) {
                angoloTotale += angoliSettori[i];
                if (angoloGradi < angoloTotale) {
                    settoreVinto = i;
                    break;
                }
            }

            JOptionPane.showMessageDialog(this, "Hai vinto il premio: " + premiSettori[settoreVinto]);
            JOptionPane.showMessageDialog(this, "Inserire il codice: " +codiciSettori[settoreVinto]);
            girata = true;
            
        }
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        disegnaRuota(g);
        disegnaFreccia(g);
    }

    private void disegnaRuota(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        int size = Math.min(getWidth(), getHeight()) - 100;
        int radius = size / 2;

        g2.translate(getWidth() / 2, getHeight() / 2);
        g2.rotate(angolo);

        int angoloAttuale = 0;

        for (int i = 0; i < numeroSettori; i++) {
            g2.setColor(colori[i % colori.length]);
            g2.fillArc(-radius, -radius, size, size, angoloAttuale, angoliSettori[i]);

            g2.setColor(Color.WHITE);
            g2.drawArc(-radius, -radius, size, size, angoloAttuale, angoliSettori[i]);

            disegnaLabel(g2, angoloAttuale + angoliSettori[i] / 2, radius, premiSettori[i]);

            angoloAttuale += angoliSettori[i];
        }

        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(4));
        g2.drawOval(-radius, -radius, size, size);

        g2.dispose();
    }

    private void disegnaLabel(Graphics2D g2, int angle, int radius, String text) {
        Font font = new Font("Arial", Font.BOLD, 18);
        g2.setFont(font);
        FontMetrics metrics = g2.getFontMetrics(font);

        double textRadius = radius * 0.65;
        int x = (int) (Math.cos(Math.toRadians(angle)) * textRadius);
        int y = (int) (Math.sin(Math.toRadians(angle)) * textRadius);

        g2.setColor(Color.BLACK);
        g2.rotate(Math.toRadians(angle), x, y);

        if (metrics.stringWidth(text) > radius / 2) {
            text = text.substring(0, Math.min(text.length(), 10)) + "...";
        }

        g2.drawString(text, x - metrics.stringWidth(text) / 2, y);
        g2.rotate(-Math.toRadians(angle), x, y);
    }

    private void disegnaFreccia(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();

        int centerX = getWidth() - 50;
        int centerY = getHeight() / 2;

        int[] xPoints = {centerX + 20, centerX, centerX + 20};
        int[] yPoints = {centerY - 10, centerY, centerY + 10};

        g2.setColor(Color.BLACK);
        g2.fillPolygon(xPoints, yPoints, 3);

        g2.dispose();
    }
    
    public static void ruota(){
        JFrame frame = new JFrame("Ruota della Fortuna");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(550, 600);
        frame.setLocationRelativeTo(null);
        frame.add(new RuotaDellaFortuna());
        frame.setVisible(true);
    }
}
