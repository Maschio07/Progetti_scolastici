package progettofinale;
import java.awt.Color;
import java.io.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Prodotto;
/**
 * @author Catellani, Gambetti, Maschio, Moretti
 */
public class Carrello extends javax.swing.JFrame {
    public static int contCarrello;
    public static float totaleCarrello;
    public static BufferedReader br;
    public static BufferedWriter bw;
    public static DefaultTableModel tm;
    public static  File file;
    
    private boolean applicato = false, girare = false, girata=false;
    private final int PREZZO_RUOTA = 2000;
    
    public Carrello() throws IOException {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("Carrello");
        this.getContentPane().setBackground(new Color(0,102,204));
        tm = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tm.setRowCount(0);
        file = new File("carrello.csv");
        leggiFile();
        
        codiceSconto.setEditable(false);
        this.totale.setText(totaleCarrello+"€");
    }
    
    public void leggiFile()throws IOException{
        if(!file.exists()){
            JOptionPane.showMessageDialog(this, "Il file"+file.getName()+"non esiste!", "Attenzione", JOptionPane.WARNING_MESSAGE);
        }
        
        else{
            tm.setRowCount(0);
            contCarrello = 0;
            totaleCarrello = 0;
            br = new BufferedReader(new FileReader(file));
            String riga = "", dati[];
            boolean pR = true;

            while((riga = br.readLine()) != null){
                dati = riga.split(",");
                if(pR){
                    tm.setColumnIdentifiers(dati);
                    pR = false;
                }
                else{
                   tm.addRow(dati);
                   totaleCarrello += Float.parseFloat(dati[2].replace("€", ""));
                   totaleCarrello = (float)Math.round(Carrello.totaleCarrello*100)/100;
                   contCarrello++;
                }
            } 
            tabella.setModel(tm);
            br.close();
        }  
    }
    
    public void rimuoviProdotto() throws IOException {
        if(!file.exists()){
            JOptionPane.showMessageDialog(this, "Il file"+file.getName()+"non esiste!", "Attenzione", JOptionPane.WARNING_MESSAGE);
        }
        
        else{
            int indiceCanc = tabella.getSelectedRow();
            if (indiceCanc == -1) {
                JOptionPane.showMessageDialog(this, "Seleziona un prodotto da rimuovere!", "Errore", JOptionPane.ERROR_MESSAGE);
            }


            BufferedReader br = new BufferedReader(new FileReader(file));
            StringBuilder nuovoContenuto = new StringBuilder();
            String riga;
            int rigaCorrente = -1;

            String primaRiga = br.readLine();  
            nuovoContenuto.append(primaRiga).append("\n");  

            while ((riga = br.readLine()) != null) {
                rigaCorrente++;
                if (rigaCorrente != indiceCanc && !riga.trim().isEmpty()) {
                    nuovoContenuto.append(riga).append("\n");
                }
            }
            br.close();

            BufferedWriter bw = new BufferedWriter(new FileWriter(file));
            bw.write(nuovoContenuto.toString().trim());  
            bw.newLine();  
            bw.close();

            aggiorna();
            this.totale.setText(totaleCarrello+"€");
            HomePage.aggiornaNumCarrello();
        }
        
}

    public static void aggiorna() throws IOException{
        if(!file.exists()){
            System.out.println("ERRORE il file non esiste");
        }
        else{
            tm.setRowCount(0);
            contCarrello = 0;
            totaleCarrello = 0;
            br = new BufferedReader(new FileReader(file));
            String riga = "";
            boolean primaRiga = true;
            while((riga = br.readLine()) != null){
                String dati[] = riga.split(",");
                if(primaRiga){
                    tm.setColumnIdentifiers(dati);
                    primaRiga = false;
                }
                else{
                    tm.addRow(dati);
                    totaleCarrello += Float.parseFloat(dati[2].replace("€",""));
                    totaleCarrello = (float)Math.round(Carrello.totaleCarrello*100)/100;
                    contCarrello++;
                }
            }
            br.close();
            Carrello.tabella.setModel(tm);
            Carrello.tabella.setVisible(true);
        }
    }
    
    public static void aggiungiOmaggio(int indice){
        Prodotto omaggio = HomePage.prodotti.get(indice);
        omaggio.setPrezzo(0);
        HomePage.controlloTaglia(omaggio);
        try {
            aggiorna();
        } catch (IOException ex) {
           JOptionPane.showMessageDialog(null, "Errore nell'aggiornamento del carrello", "ERRORE", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tabella = new javax.swing.JTable();
        rimuovi = new javax.swing.JButton();
        chiudi = new javax.swing.JButton();
        ricevuta = new javax.swing.JCheckBox();
        ruota = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        conferma = new javax.swing.JButton();
        totale = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        codiceSconto = new javax.swing.JTextField();

        setBackground(new java.awt.Color(0, 102, 204));

        tabella.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabella);

        rimuovi.setText("Rimuovi dal carrello");
        rimuovi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rimuoviActionPerformed(evt);
            }
        });

        chiudi.setText("Continua ad acquistare");
        chiudi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chiudiActionPerformed(evt);
            }
        });

        ricevuta.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ricevuta.setForeground(new java.awt.Color(255, 255, 255));
        ricevuta.setText("Scarica ricevuta");
        ricevuta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ricevutaActionPerformed(evt);
            }
        });

        ruota.setText("Gira e vinci");
        ruota.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ruotaActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Totale: ");

        conferma.setText("Conferma ordine");
        conferma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confermaActionPerformed(evt);
            }
        });

        totale.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        totale.setForeground(new java.awt.Color(255, 204, 255));
        totale.setText("tanto");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Codice sconto: ");

        codiceSconto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codiceScontoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 487, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ricevuta)
                    .addComponent(ruota, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(conferma, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(chiudi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(totale))
                    .addComponent(rimuovi, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(codiceSconto)))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(totale))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ricevuta)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(codiceSconto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(conferma)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ruota)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(rimuovi)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(chiudi))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rimuoviActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rimuoviActionPerformed
        try {
            rimuoviProdotto();
        } catch (IOException ex) {
            System.out.println("ERRORE in rimuoviProdotto()");
        }
    }//GEN-LAST:event_rimuoviActionPerformed

    private void chiudiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chiudiActionPerformed
        this.dispose();
        HomePage.aggiornaNumCarrello();
    }//GEN-LAST:event_chiudiActionPerformed

    private void ricevutaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ricevutaActionPerformed
        
    }//GEN-LAST:event_ricevutaActionPerformed

    private void ruotaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ruotaActionPerformed
        if(totaleCarrello<PREZZO_RUOTA)
            JOptionPane.showMessageDialog(this, "Non hai raggiunto la spesa minima per girare la ruota (2000€)");
        else if(girata)
            JOptionPane.showMessageDialog(this, "Hai già girato la ruota per quest'ordine");
        else { 
        RuotaDellaFortuna.ruota();
        girata = true;
        }
        codiceSconto.setEditable(true);
    }//GEN-LAST:event_ruotaActionPerformed

    private void confermaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confermaActionPerformed
        if(totaleCarrello>0)
            new Pagamento().setVisible(true);
        else
            JOptionPane.showMessageDialog(this, "Il carrello e' vuoto");
    }//GEN-LAST:event_confermaActionPerformed

    private void codiceScontoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codiceScontoActionPerformed
        String sconto = codiceSconto.getText().trim().toUpperCase();
        
        if (!applicato) {
        for (int i = 0; i < 10; i++) {
            if (sconto.equals(RuotaDellaFortuna.codiciSettori[i])) {
                switch (i) {
                    case 0:
                        aggiungiOmaggio((int)(25 + Math.random() * 5));
                        break;
                    case 1:
                        totaleCarrello *= 0.9;
                        break;
                    case 2:
                        aggiungiOmaggio((int)(20 + Math.random() * 5));
                        break;
                    case 3:
                        totaleCarrello -= 20;
                        break;
                    case 4:
                        totaleCarrello *= 0.8;
                        break;
                    case 5:
                        aggiungiOmaggio(30);
                        break;
                    case 6:
                        totaleCarrello -= 30;
                        break;
                    case 7:
                        totaleCarrello *= 0.95;
                        break;
                    case 8:
                        totaleCarrello -= 5;
                        break;
                    case 9:
                        aggiungiOmaggio(31);
                        break;
                    default:
                        JOptionPane.showMessageDialog(this, "Codice inserito non valido.");
                }

                JOptionPane.showMessageDialog(this, "Codice: " + sconto + " applicato con successo");
                applicato = true;
                break; //uscita dal for
            }
        }
    }

        else JOptionPane.showMessageDialog(this, "Hai già applicato un codice Sconto!");
        totaleCarrello = (float)Math.round(Carrello.totaleCarrello*100)/100;
        this.totale.setText(totaleCarrello+"€");
    }//GEN-LAST:event_codiceScontoActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Carrello.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Carrello.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Carrello.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Carrello.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Carrello().setVisible(true);
                } catch (IOException ex) {
                    System.out.println("ERRORE!");
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton chiudi;
    private javax.swing.JTextField codiceSconto;
    private javax.swing.JButton conferma;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JCheckBox ricevuta;
    private javax.swing.JButton rimuovi;
    private javax.swing.JButton ruota;
    public static javax.swing.JTable tabella;
    public static javax.swing.JLabel totale;
    // End of variables declaration//GEN-END:variables
}
