package model;
/**
 *
 * @author mario
 */
public class Calzature extends Prodotto{
    public static String taglie[] = {"Nessuna","35","36","37","38","39","40", "41","42","43","44","45"};
    public Calzature(float prezzo, String percorsoIMG, String taglia, String nome) {
        super(prezzo, percorsoIMG, taglia, nome);
    }
    
}
