package model;
/**
 *
 * @author mario
 */
public class Profumo extends Prodotto{
    public static String taglie[] = {"Nessuna","30 ml","50 ml","75 ml","100 ml"};
    public Profumo(float prezzo, String percorsoIMG, String taglia, String nome) {
        super(prezzo, percorsoIMG, taglia, nome);
    }
    
    public float regolaPrezzo(){
        switch(this.getTaglia()){
            case "50 ml": return (float) 0.99 + (int) (this.prezzo*1.5);
            case "75 ml": return (float) 0.99 + (int) (this.prezzo*2.5);
            case "100 ml": return (float) 0.99 + (int) (this.prezzo*2.75);
            default: return this.prezzo;
        }
    }
}
