package model;
/**
 *
 * @author mario
 */
public class Abbigliamento extends Prodotto{
    public static String taglie[] = {"Nessuna","XS","S","M","L","XL","XXL", "Nessuna"};
    public Abbigliamento(float prezzo, String percorsoIMG, String taglia, String nome) {
        super(prezzo, percorsoIMG, taglia, nome);
    }
    
}
