package model;
/**
 *
 * @author maschio.mario
 */
public class Prodotto {
    public static String taglie[] = {"Nessuna","Taglia unica"};
    protected String taglia;
    protected String nome;
    protected float prezzo;
    protected String percorsoIMG;

    public Prodotto(float prezzo, String percorsoIMG, String taglia, String nome) {
        this.nome = nome;
        this.prezzo = prezzo;
        this.percorsoIMG = percorsoIMG;
        this.taglia = taglia;
    }
    
    //Getter
    public String getTaglia() {
        return taglia;
    }
    
    public float getPrezzo() {
        return prezzo;
    }
    
    public String getPercorsoIMG() {
        return percorsoIMG;
    }

    public String getNome() {
        return nome;
    }
    
    //Setter
    public void setTaglia(String taglia) {
        this.taglia = taglia;
    }
    
    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }

    public void setPercorsoIMG(String percorsoIMG) {
        this.percorsoIMG = percorsoIMG;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
}
