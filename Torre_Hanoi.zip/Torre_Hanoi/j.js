let lSX = [];
let lDX = [];
let lC = [];
let ultimaMossa = 0;
let ultimaColonna = 0;
let mosseTot = 0;
const coloreSelect = document.getElementById("coloreRettangoli");
const hColonna = 91;
let colore = coloreSelect.value;
inizioColonna(2);
const input = document.getElementById('numeroRettangoli');
let mosseUtente=2;
// Impedire la modifica da tastiera
input.addEventListener('keydown', function(event) {
    event.preventDefault(); // Blocca la pressione di qualsiasi tasto    
});
input.addEventListener('input', function() {
    mosseUtente = parseInt(document.getElementById("numeroRettangoli").value);
    document.getElementById("mosseMin").textContent = 2**mosseUtente-1;
    inizioColonna(mosseUtente);
});

window.addEventListener('DOMContentLoaded', () => {
    document.getElementById("numeroRettangoli").value = 2;
    mosseUtente = parseInt(document.getElementById("numeroRettangoli").value);
    document.getElementById("mosseMin").textContent = 2**mosseUtente-1;
    inizioColonna(mosseUtente);
});

function eliminazioneCasuale(c) {
    const container = document.getElementById(c.id);
    const children = container.querySelectorAll("div"); // Seleziona tutti i div (rettangoli)
    children.forEach(child => {
         if (!child.classList.contains("palo") && !child.classList.contains("base")) {
            child.remove();
        }
    });
}
function creazioneColonnaCasuale(c,list){
    const container = document.getElementById(c.id);
    let hColonnaSing = ((hColonna)/mosseUtente);
    const children = document.querySelectorAll("*");
    for(let i = 0;i<list.length;i++){        
        let rettangolo = list[i];
        let topC = (95-(hColonnaSing*(i+1)));
        rettangolo.style.top = topC+"%";
        container.appendChild(rettangolo);          
    }
}
function inizioColonna(mU){
    eliminazioneCasuale(document.getElementById("colonnaSX"));
    eliminazioneCasuale(document.getElementById("colonnaDX"));
    eliminazioneCasuale(document.getElementById("colonnaCentro"));
    lSX = [];
    lDX = [];
    lC = [];

    const container = document.getElementById("colonnaSX");
    const children = document.querySelectorAll("*");

    children.forEach(child => {
        if(child.style.backgroundColor === colore)child.remove();
    });

    for(let i = 1;i<=mU;i++){
        const c = document.getElementById("colonnaSX");
        const rettangolo = document.createElement("div");
        let wColonnaSing = (100-(18))-(i*5); // Larghezza colonna
        let hColonnaSing = ((100-9)/mU); // Altezza colonna
        let topC = (95-(hColonnaSing*i));
        
        rettangolo.style.width = wColonnaSing+"%";
        rettangolo.style.height = hColonnaSing+"%";
        rettangolo.style.top = topC+"%";
        rettangolo.style.border = "1px solid black";
        rettangolo.style.backgroundColor = colore;
        rettangolo.style.position = "absolute";

        c.appendChild(rettangolo);    
        lSX.push(rettangolo);        
    }   
    mosseTot = 0;
    document.getElementById("mosseR").textContent = mosseTot;
}
function setContorno(c){
    const container = document.getElementById(c.id);
    container.style.border = "none";
}
function cancellaTutto(){
    eliminazioneCasuale(document.getElementById("colonnaSX"));
    eliminazioneCasuale(document.getElementById("colonnaDX"));
    eliminazioneCasuale(document.getElementById("colonnaCentro"));
}
function aggiornaColoreRettangoli() {
    // Rimuovi i rettangoli esistenti
    eliminazioneCasuale(document.getElementById("colonnaSX"));
    eliminazioneCasuale(document.getElementById("colonnaDX"));
    eliminazioneCasuale(document.getElementById("colonnaCentro"));

    // Poi, ricrea i rettangoli con il nuovo colore
    inizioColonna(mosseUtente);
}
function disegnaTutto(){
    cancellaTutto();
    creazioneColonnaCasuale(document.getElementById("colonnaSX"),lSX);
    creazioneColonnaCasuale(document.getElementById("colonnaDX"),lDX);
    creazioneColonnaCasuale(document.getElementById("colonnaCentro"),lC);
}
//implementazione dei mouselistener
const colonna1 = document.getElementById('colonnaSX');
const colonne2 = document.getElementById('colonnaDX');
const colonna3 = document.getElementById('colonnaCentro');
let last = 0;
let lastLista = [];
let flag = true;
colonna1.addEventListener('click', function(e) {  
    e.stopPropagation();   // Impedisce che l'evento venga preso dal listener globale
    if(flag){                
        let container = document.getElementById("colonnaSX");
        ultimaColonna = container;
        ultimaColonna.style.border = "1px solid blue";
        last = lSX.pop();
        lastLista = lSX;
        flag = false;
    }
    else{
        if(lSX.length == 0||last.style.width < lSX[lSX.length-1].style.width){
            lSX.push(last);        
            disegnaTutto();
            ultimaColonna.style.border = "none";
            ultimaColonna = 0;
            lastLista = []; 
            flag = true;
            mosseTot++;
            document.getElementById("mosseR").textContent = mosseTot;
        }
    }
});
colonne2.addEventListener('click', function(e) { 
    e.stopPropagation();    // Impedisce che l'evento venga preso dal listener globale
    if(flag){        
        let container = document.getElementById("colonnaDX");
        ultimaColonna = container;
        container.style.border = "1px solid blue";
        last = lDX.pop();
        lastLista = lDX;
        flag = false;         
    }    
    else{
        if(lDX.length == 0||last.style.width < lDX[lDX.length-1].style.width){
            lDX.push(last);
            disegnaTutto();
            ultimaColonna.style.border = "none";
            ultimaColonna = 0;
            lastLista = []; 
            flag = true;  
            mosseTot++;
            document.getElementById("mosseR").textContent = mosseTot;  
        }                    
    }
    setTimeout(() => {
        if(lDX.length == mosseUtente){
            alert("Hai vinto!");  
            inizioColonna(mosseUtente);          
        }
    }, 100); 
});
colonna3.addEventListener('click', function(e) {
    e.stopPropagation();    // Impedisce che l'evento venga preso dal listener globale
    if(flag){        
        const container = document.getElementById("colonnaCentro");
        ultimaColonna = container;
        container.style.border = "1px solid blue";
        last = lC.pop();
        lastLista = lC;
        flag = false; 
    }
    else{
        if(lC.length == 0||last.style.width < lC[lC.length-1].style.width){
            lC.push(last);
            disegnaTutto();
            ultimaColonna.style.border = "none";
            ultimaColonna = 0;
            lastLista = []; 
            flag = true;  
            mosseTot++;
            document.getElementById("mosseR").textContent = mosseTot;
        }
    } 
    setTimeout(() => {
        if(lC.length == mosseUtente){
            alert("Hai vinto!");  
            inizioColonna(mosseUtente);          
        }
    }, 100);
});
//listener per cambiare colore con il select
coloreSelect.addEventListener('change', function() {
    colore = coloreSelect.value; 
    aggiornaColoreRettangoli(); 
});
document.addEventListener('click', function() {
    switch(ultimaColonna.id){
        case "colonnaSX":
            setContorno(document.getElementById(ultimaColonna.id));
            lSX.push(last);
            break;
        case "colonnaDX":
            setContorno(document.getElementById(ultimaColonna.id));
            lDX.push(last);
            break;
        case "colonnaCentro":
            setContorno(document.getElementById(ultimaColonna.id));
            lC.push(last);
            break;
    }
    ultimaColonna = 0;
    last = 0;
    lastLista = [];
    flag = true;
});
